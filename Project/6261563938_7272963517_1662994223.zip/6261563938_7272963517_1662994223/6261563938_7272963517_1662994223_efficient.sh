#!/bin/bash
python3 6261563938_7272963517_1662994223_efficient.py input.txt